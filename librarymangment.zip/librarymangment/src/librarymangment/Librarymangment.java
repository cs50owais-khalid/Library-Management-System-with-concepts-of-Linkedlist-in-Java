/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymangment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author LENOVO
 */
public class Librarymangment {

    /**
     */
     public static Connection conn = null;
    
    public static void main(String[] args) throws SQLException  {
        
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarymangment", "root", "");
        
        homepage ob=new homepage();
        ob.setVisible(true);
  
    }
    
}