///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package librarymangment;
//
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileReader;
//import java.io.IOException;
//import java.io.PrintWriter;
//
///**
// *
// * @author Welcome
// */
//public class Filing {
//    
//    
//     public  void WriteToFile(String[] lines ,String path) throws IOException {
//               int lineNumber = 0;
//    PrintWriter writer = new PrintWriter(path, "UTF-8");
//    // für jeden String (eingelesene Zeile) in der Arraylist
//    for( String line: lines) {
//        // Counter für die Zeilennummern
//        if(line != null){
//            writer.println(line);
//            lineNumber++;
//        }
//        }
//    // Writer schließen
//    writer.close(); 
//    }
//     public  String[] readAllData(String path , int Count){ 
//        File fpath = new File(path);
//        String[] array = new String[Count];
//        int i = 0;
//        try{
//            try (BufferedReader reader = new BufferedReader (new FileReader(fpath));){
//                String currentLine;
//                while((currentLine = reader.readLine()) != null) {
//                    array[i] = currentLine;
//                    i++;
//                }
//            }
//        } catch (IOException e){
//            
//        }
//        return array;
//    }  
//     public  int getLineCount(String path){ 
//        File fpath = new File(path);
//        int i = 1;
//        try{
//            try (BufferedReader reader = new BufferedReader (new FileReader(fpath));){
//                String currentLine;
//                while((currentLine = reader.readLine()) != null) {
//                    i++;
//                }
//            }
//        } catch (IOException e){
//            
//        }
//        return i;
//    }
//    
//    
//}
