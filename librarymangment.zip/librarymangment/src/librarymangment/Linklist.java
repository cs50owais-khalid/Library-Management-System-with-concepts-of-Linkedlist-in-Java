/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymangment;


public class Linklist  {
    
      private Node Head;
      private int Count = 0;

  
    Linklist(){
    this.Head = null;
    }     
    public void add(String[] a){
       for(int i = 0 ; i < a.length-1; i++){
       this.insertItemAtFirst(a[i]);
       }
    }
    //insert at first
    public boolean insertItemAtFirst(String s){
       Node n = new Node();
       n.value = s;
       n.next = Head;
       Head = n;
       Count++;
       return true;
    }
       //insert at Last
    public boolean insertItemAtLast(String item){
         Node z = Head;
        while(z.next != null){
        z = z.next ;
        }
       Node n = new Node();
       n.value = item;
       n.next = null;
       z.next  = n;
        Count++;
        return true;
    }
    //getAt
    public String getAt(int i){
        int x = 0;
        Node z = Head;
        while(z != null){
         if(x == i){
         return z.value;
         }
         x++;
        z = z.next;
        }
        return "null";
    }
    
    //print all
    public void  print(){
        Node z = Head;
        while(z != null){
        System.out.println(z.value);
        z = z.next;
     
        }
    }
    //get Data
       public  String[] getData(){
         String[] data = new String[Count];
        int i = 0;
        Node z = Head;
        while(z != null){
         data[i] = z.value;
         i++;
        z = z.next;
        }
        return  data;
         }
    //delete item
    public  boolean DeleteAtAnyPoint(String item){ 
      if(isEmpty()){
        return false;
      }else{
          if(item == Head.value){
              Head = Head.next;
               Count--;
              return true;
          }else{
         
          Node p = Head;
          Node temp = null;
          while(p.value != item){
              temp = p;
          p = p.next;
          }
          
          temp.next = p.next ;
          Count--;
        return true;
         }
      }
    }
//    
    //Delete From Last
     public  boolean DeleteFromLast(){
         if(isEmpty()){ return false;}else{
         Node p = Head;
         Node temp = null;
         while(p.next != null){
          temp = p;
          p = p.next;
         }
         temp.next = p.next;
         Count--;
         return true;
         
         }
        }
     //Delete From First
     public boolean DeleteAtFirst(){
         if(isEmpty()){
         return false;
         }
      Head = Head.next;
      Count--;
      return true;
     }
    public boolean isEmpty(){return Head == null;}
    
    public int Counter(){return Count;}

    //node
    class Node
    {
        public String value;
        private Node next;
    }       
}
